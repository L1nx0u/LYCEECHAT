# serveur.py

import socket
import threading

# Configuration du serveur
HOST = '0.0.0.0'  # Écoute sur toutes les interfaces réseau disponibles
PORT = 12345      # Port à utiliser (choisissez un nombre > 1024)

# Liste pour garder la trace des clients connectés
clients = []

# Fonction pour diffuser les messages à tous les clients
def diffuser_message(message, auteur_conn):
    for client in clients:
        # On n'envoie pas le message à l'auteur original
        if client != auteur_conn:
            try:
                client.send(message)
            except:
                # Si l'envoi échoue, on retire le client
                client.close()
                clients.remove(client)

# Fonction pour gérer chaque client individuellement
def gerer_client(conn, addr):
    print(f"[NOUVELLE CONNEXION] {addr} connecté.")
    
    # Ajoute le nouveau client à la liste
    clients.append(conn)

    while True:
        try:
            # Réception du message (jusqu'à 2048 bytes)
            message = conn.recv(2048)
            if message:
                print(f"[{addr}] a envoyé un message crypté.")
                # Diffuse le message aux autres clients
                diffuser_message(message, conn)
                
                # Sauvegarde dans un fichier (notre "base de données")
                with open("historique.txt", "a") as f:
                    f.write(message.decode('utf-8', errors='ignore') + "\n")

            else:
                # Si le message est vide, le client s'est déconnecté
                print(f"[{addr}] s'est déconnecté.")
                conn.close()
                clients.remove(conn)
                break
        except:
            print(f"[{addr}] Erreur de connexion.")
            conn.close()
            clients.remove(conn)
            break

# Fonction principale du serveur
def demarrer_serveur():
    serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serveur.bind((HOST, PORT))
    serveur.listen()
    print(f"[DÉMARRAGE] Le serveur écoute sur le port {PORT}")
    
    # Affiche l'adresse IP locale à partager
    hostname = socket.gethostname()
    ip_locale = socket.gethostbyname(hostname)
    print(f"Partagez cette adresse IP à vos amis : {ip_locale}")

    while True:
        # Accepte une nouvelle connexion
        conn, addr = serveur.accept()
        # Crée un thread pour gérer ce nouveau client
        thread = threading.Thread(target=gerer_client, args=(conn, addr))
        thread.start()

demarrer_serveur()