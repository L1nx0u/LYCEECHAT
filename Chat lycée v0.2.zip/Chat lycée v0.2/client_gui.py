# client_gui.py

# Imports pour le réseau et le cryptage
import socket
import threading
import base64
from cryptography.fernet import Fernet
from config import CLE_CRYPTAGE # Importe la clé secrète

# Imports pour l'interface graphique et l'icône
import tkinter as tk
from tkinter import scrolledtext, simpledialog, messagebox
from pystray import MenuItem as item
import pystray
from PIL import Image, ImageDraw
import queue  # Import pour la file d'attente sécurisée

# Initialise le système de cryptage
fernet = Fernet(CLE_CRYPTAGE)

# --- Fonctions de cryptage ---
def crypter_message(message):
    # D'abord, on crypte avec la clé (Fernet encode déjà en Base64)
    message_crypte = fernet.encrypt(message.encode('utf-8'))
    # Ensuite, on encode en Base64 pour le transport (pour correspondre au serveur)
    return base64.b64encode(message_crypte)

def decrypter_message(message_b64):
    try:
        # D'abord, on décode le Base64
        message_crypte = base64.b64decode(message_b64)
        # Ensuite, on décrypte avec la clé
        message_clair = fernet.decrypt(message_crypte).decode('utf-8')
        return message_clair
    except Exception as e:
        # Si le décryptage échoue (ex: mauvaise clé ou message corrompu)
        # print(f"Erreur de décryptage : {e}") # Peut être utile pour le débogage
        return ">>> Message illisible <<<"

# --- Variables globales ---
client_socket = None
fenetre = None
icon = None
message_queue = queue.Queue() # Notre "panier" pour les messages

# --- Fonctions de l'interface ---
def ajouter_message(message):
    """ Ajoute un message dans la zone de texte de la fenêtre """
    zone_chat.config(state=tk.NORMAL)
    zone_chat.insert(tk.END, message + "\n")
    zone_chat.config(state=tk.DISABLED)
    zone_chat.yview(tk.END)

def envoyer_message(event=None):
    """ Envoie le message du champ de saisie et l'affiche localement """
    message = champ_saisie.get()
    if message and client_socket:
        message_final = f"{pseudo} > {message}"
        
        # NOUVEAU : Afficher le message localement AVANT de l'envoyer
        ajouter_message(message_final) 
        
        # Crypter et envoyer le message au serveur
        client_socket.send(crypter_message(message_final))
        
        # Vider le champ de saisie
        champ_saisie.delete(0, tk.END)

def recevoir_messages():
    """ Tourne en boucle, reçoit les messages et les met dans la queue """
    while True:
        try:
            message_recu = client_socket.recv(2048)
            if message_recu:
                # print(f"[DEBUG THREAD] Message reçu du serveur (Taille: {len(message_recu)} octets).")
                message_clair = decrypter_message(message_recu)
                
                # Le décryptage peut échouer
                if message_clair != ">>> Message illisible <<<":
                    message_queue.put(message_clair)
                    # print(f"[DEBUG THREAD] Message clair mis en queue: {message_clair[:30]}...")
                else:
                    message_queue.put(message_clair) # On met quand même le message d'erreur
            else:
                break
        except Exception as e:
            message_queue.put(f"[SERVEUR] Connexion perdue. Erreur: {e}")
            break

def verifier_queue():
    """ Vérifie s'il y a des messages dans la queue et les affiche """
    messages_affiches = 0
    while not message_queue.empty():
        message = message_queue.get()
        ajouter_message(message)
        messages_affiches += 1
        
    if messages_affiches > 0:
        # print(f"[DEBUG TKINTER] {messages_affiches} message(s) affiché(s).")
        pass
        
    # On demande à Tkinter de revérifier dans 100ms
    fenetre.after(100, verifier_queue)

# --- Fonctions pour l'icône de la barre des tâches ---
def cacher_fenetre():
    """ Cache la fenêtre et démarre l'icône dans la zone de notification """
    fenetre.withdraw()
    image = creer_image_icone()
    global icon
    menu = (item('Afficher', afficher_fenetre, default=True), item('Quitter', quitter_app))
    icon = pystray.Icon("name", image, "Chat du Lycée", menu)
    icon.run()

def afficher_fenetre():
    """ Arrête l'icône et ré-affiche la fenêtre """
    if icon:
        icon.stop()
    fenetre.deiconify()

def quitter_app():
    """ Fonction pour fermer proprement l'application """
    if messagebox.askokcancel("Quitter", "Voulez-vous vraiment quitter le chat ?"):
        if icon:
            icon.stop()
        if client_socket:
            client_socket.close()
        fenetre.quit()
        fenetre.destroy()

def creer_image_icone():
    """ Crée une image simple pour l'icône """
    width, height, color1, color2 = 64, 64, (0, 0, 0, 0), (0, 150, 255)
    image = Image.new('RGBA', (width, height), color1)
    dc = ImageDraw.Draw(image)
    dc.rectangle((width // 2, 0, width, height // 2), fill=color2)
    dc.rectangle((0, height // 2, width // 2, height), fill=color2)
    return image

# --- Programme Principal ---

# 1. Fenêtre de connexion
dialogue_connexion = tk.Tk()
dialogue_connexion.withdraw()
ip_serveur = simpledialog.askstring("Connexion", "Entrez l'adresse IP du serveur :", parent=dialogue_connexion)
pseudo = simpledialog.askstring("Connexion", "Entrez votre pseudo :", parent=dialogue_connexion)

if not ip_serveur or not pseudo:
    print("Connexion annulée.")
else:
    # 2. Création de la fenêtre principale du chat
    fenetre = tk.Tk()
    fenetre.title(f"Chat du Lycée - Connecté en tant que {pseudo}")

    # Zone d'affichage des messages
    zone_chat = scrolledtext.ScrolledText(fenetre, state=tk.DISABLED, wrap=tk.WORD, bg="#f0f0f0", fg="black")
    zone_chat.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

    # Zone de saisie du message
    champ_saisie = tk.Entry(fenetre, bg="white", fg="black", font=("Helvetica", 10))
    champ_saisie.pack(padx=10, pady=(0, 10), fill=tk.X, expand=False)
    champ_saisie.bind("<Return>", envoyer_message) # Envoyer avec la touche Entrée

    # 3. Connexion au serveur
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((ip_serveur, 12345))
        
        # Envoi du pseudo au serveur
        client_socket.send(pseudo.encode('utf-8'))

        # Le message de connexion est mis dans la queue
        message_queue.put("[SERVEUR] Connecté au serveur ! 🎉") 

        # Lance le thread pour recevoir les messages
        thread_reception = threading.Thread(target=recevoir_messages, daemon=True)
        thread_reception.start()

    except Exception as e:
        message_queue.put(f"[ERREUR] Connexion impossible : {e}")

    # 4. Association des fonctions aux actions de la fenêtre
    fenetre.protocol('WM_DELETE_WINDOW', cacher_fenetre)
    
    # 5. Démarrage de la vérification de la queue
    fenetre.after(100, verifier_queue)
    
    fenetre.mainloop()