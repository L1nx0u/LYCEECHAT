# client.py

import socket
import threading
import base64
from cryptography.fernet import Fernet
from config import CLE_CRYPTAGE # Importe la clé secrète

# Initialise le système de cryptage
fernet = Fernet(CLE_CRYPTAGE)

def crypter_message(message):
    # D'abord, on crypte avec la clé
    message_crypte = fernet.encrypt(message.encode('utf-8'))
    # Ensuite, on encode en Base64 pour un envoi facile (optionnel mais courant)
    return base64.b64encode(message_crypte)

def decrypter_message(message_b64):
    try:
        # D'abord, on décode le Base64
        message_crypte = base64.b64decode(message_b64)
        # Ensuite, on décrypte avec la clé
        message_clair = fernet.decrypt(message_crypte).decode('utf-8')
        return message_clair
    except Exception as e:
        # Si le décryptage échoue (ex: mauvaise clé ou message corrompu)
        print(f"Erreur de décryptage : {e}")
        return ">>> Message illisible <<<"


# Fonction pour recevoir les messages du serveur
def recevoir_messages(client_socket):
    while True:
        try:
            message_recu = client_socket.recv(2048)
            if message_recu:
                message_clair = decrypter_message(message_recu)
                print(message_clair)
        except:
            print("Erreur de connexion avec le serveur. Fermeture.")
            client_socket.close()
            break

# Fonction principale du client
def demarrer_client():
    # Demande l'IP du serveur et le pseudo de l'utilisateur
    ip_serveur = input("Entrez l'adresse IP du serveur : ")
    pseudo = input("Entrez votre pseudo : ")

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client.connect((ip_serveur, 12345)) # Le port doit être le même que celui du serveur
    except:
        print("Connexion échouée. Vérifiez l'adresse IP et que le serveur est bien lancé.")
        return

    # Crée un thread pour écouter les messages du serveur en continu
    thread_reception = threading.Thread(target=recevoir_messages, args=(client,))
    thread_reception.daemon = True # Permet au programme de se fermer même si le thread tourne
    thread_reception.start()

    print("\nConnecté au chat ! Tapez vos messages et appuyez sur Entrée. (tapez 'quit' pour quitter)")

    # Boucle pour envoyer des messages
    while True:
        message = input()
        if message.lower() == 'quit':
            client.close()
            break
        
        # Formate le message avec le pseudo
        message_final = f"{pseudo} > {message}"
        
        # Crypte et envoie le message
        client.send(crypter_message(message_final))

demarrer_client()