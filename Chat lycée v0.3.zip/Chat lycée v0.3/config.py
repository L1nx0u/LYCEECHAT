# config.py

# IMPORTANT : Tout le monde doit avoir la même clé !
# Gardez cette clé secrète. Vous pouvez la générer une fois et la partager avec vos amis.
# Pour générer une nouvelle clé, lancez python et tapez :
# from cryptography.fernet import Fernet
# Fernet.generate_key()
# Copiez-collez le résultat ici.
CLE_CRYPTAGE = b'p5N9dAnYv8S1nIsfL8A9oG_yXmJzZ2aRb3c4d5e6f7g='