# serveur.py (Version avec Affichage du Pseudo)

import socket
import threading
import sys
import base64
from cryptography.fernet import Fernet
from config import CLE_CRYPTAGE 

# Configuration du serveur
HOST = '0.0.0.0'
PORT = 12345

# Liste pour garder la trace des clients connectés
clients = []

# Initialise le système de cryptage
fernet_server = Fernet(CLE_CRYPTAGE) 

# Fonction utilitaire de cryptage pour le serveur
def crypter_message_serveur(message):
    message_crypte = fernet_server.encrypt(message.encode('utf-8'))
    return base64.b64encode(message_crypte)

# Fonction pour diffuser les messages à tous les clients
def diffuser_message(message, auteur_conn=None):
    for client in clients:
        if client != auteur_conn:
            try:
                client.send(message)
            except:
                client.close()
                if client in clients:
                    clients.remove(client)

# Fonction pour interagir avec le serveur via la console
def commande_serveur():
    while True:
        try:
            commande = input("SERVEUR > ")
            if commande.lower() == 'test':
                message_clair = "[SERVEUR] Message de test crypté réussi ! La connexion est stable."
                message_a_envoyer = crypter_message_serveur(message_clair)
                
                diffuser_message(message_a_envoyer)
                print("[SERVEUR] Message de test CRYPTÉ envoyé à tous les clients.")
            elif commande.lower() == 'quit':
                print("[SERVEUR] Arrêt en cours...")
                sys.exit(0)
            elif commande:
                print(f"[SERVEUR] Commande inconnue : {commande}")
        except EOFError:
            sys.exit(0)
        except Exception as e:
            print(f"[SERVEUR ERREUR] Erreur de commande : {e}")


# Fonction pour gérer chaque client individuellement (MODIFIÉE)
def gerer_client(conn, addr):
    # NOUVEAU : Réception du pseudo juste après la connexion
    try:
        pseudo = conn.recv(1024).decode('utf-8')
    except:
        pseudo = "Inconnu"

    print(f"[NOUVELLE CONNEXION] {pseudo} ({addr[0]}) connecté(e).") # Affichage du pseudo!
    clients.append(conn)

    while True:
        try:
            message = conn.recv(2048)
            if message:
                # Affichage du pseudo à l'envoi du message
                print(f"[{pseudo}] a envoyé un message crypté. (Taille: {len(message)} octets)")
                
                diffuser_message(message, conn)
                
                with open("historique_brut.txt", "ab") as f:
                    f.write(message + b"\n")

            else:
                # Déconnexion
                print(f"[{pseudo}] s'est déconnecté(e).")
                conn.close()
                if conn in clients:
                    clients.remove(conn)
                break
        except:
            print(f"[{pseudo}] Erreur de connexion/Déconnexion forcée.")
            conn.close()
            if conn in clients:
                clients.remove(conn)
            break

# Fonction principale du serveur
def demarrer_serveur():
    serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        serveur.bind((HOST, PORT))
    except OSError as e:
        print(f"Erreur de bind : {e}. Le port {PORT} est probablement déjà utilisé.")
        sys.exit(1)
        
    serveur.listen()
    print(f"[DÉMARRAGE] Le serveur écoute sur le port {PORT}")
    
    hostname = socket.gethostname()
    ip_locale = socket.gethostbyname(hostname)
    print(f"Partagez cette adresse IP à vos amis : {ip_locale}")

    thread_commandes = threading.Thread(target=commande_serveur)
    thread_commandes.daemon = True
    thread_commandes.start()

    while True:
        conn, addr = serveur.accept()
        thread = threading.Thread(target=gerer_client, args=(conn, addr))
        thread.start()

# Lance le serveur
if __name__ == '__main__':
    demarrer_serveur()